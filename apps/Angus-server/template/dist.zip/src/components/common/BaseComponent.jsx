import AText from "../widget/a-text/AText";
import AButton from "../widget/a-button/AButton";
import AImage from "../widget/a-image/AImage";
import ARectAngle from "../widget/a-rectangle/ARectAngle";
import AInput from "../widget/a-input/AInput";
import { WidgetType } from "../../config";

const BaseComponent = (props) => {
  const { widget } = props;
  const config = {
    widget,
  };
  switch (widget.type) {
    case WidgetType.AButton:
      return <AButton {...config} />;
    case WidgetType.AText:
      return <AText {...config} />;
    case WidgetType.AImage:
      return <AImage {...config} />;
    case WidgetType.ARectangle:
      return <ARectAngle {...config} />;
    case WidgetType.AInput:
      return <AInput {...config} />;
    default:
      return null;
  }
};
export default BaseComponent;
