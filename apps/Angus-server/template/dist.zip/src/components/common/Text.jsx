const Text = ()=>{
    return (
        <div>
            Text
        </div>
    )
}
export default Text