const AImage = ({ style, url, title, className }) => {
  const config = { ...style, position: "absolute" };
  const handleImageDown = (e) => {
    e.preventDefault();
  };

  return (
    <div className="a-image">
      <img
        className={className}
        title={title}
        onMouseDown={handleImageDown}
        style={config}
        src={url}
        alt={title}
      />
    </div>
  );
};

export default AImage;
