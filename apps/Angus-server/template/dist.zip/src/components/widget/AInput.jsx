const AInput = ({ style, placeholder, className }) => {
  const config = { ...style, position: "absolute" };
  return (
    <input
      style={config}
      className={className}
      placeholder={placeholder}
    ></input>
  );
};
export default AInput;
