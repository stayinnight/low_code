const AText = ({ style, propValue, title, className }) => {
  const config = { ...style, position: "absolute" };
  return (
    <div className={className} title={title} style={config}>
      {propValue}
    </div>
  );
};

export default AText;
