const AButton = ({ propValue, style, title }) => {
  const config = { ...style, position: "absolute" };
  
  return (
    <button
      title={title}
      style={config}
    >
      {propValue}
    </button>
  );
};
export default AButton;
