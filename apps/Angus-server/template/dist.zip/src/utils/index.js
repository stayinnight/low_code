export const componse = (...arg) => {
  return (Widget) => {
    let Component = Widget;
    const overlay = () => {
      arg.forEach((fn) => {
        Component = fn(Component)()
      });
    };
    overlay();
    return Component
  };
};
