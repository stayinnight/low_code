/*为组件添加类名的高阶组件*/
export const addClass = (className) => {
  return (Widget) => {
    return () => {
      return <div className={className}>{Widget}</div>;
    };
  }
};

/*给组件添加事件的高阶组件*/
export const addEvent = (name, cb) => {
  return (Widget) => {
    return () => {
      switch (name) {
        case "onClick":
          return <div onClick={cb}>{Widget}</div>;
        case "onChange":
          return <div onChange={cb}>{Widget}</div>;
        default:
          break;
      }
    };
  };
};
/*为一个组件添加其他部分的装饰器*/
export const addElement = (element) => {
  return (Widget) => {
    return () => (
      <div>
        {element}
        {Widget}
      </div>
    );
  };
};
