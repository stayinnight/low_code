import RouterView from "./router/router";
import "./app.css";

function App() {
  return <RouterView/>
}

export default App;
