import { HashRouter as Router, Route, Switch, Redirect } from "react-router-dom";
      
          import Home from '../pages/Home'
 
          import Profile from '../pages/Profile'
 
      const RouterView = () => {
        return (
          <Router>
          <Redirect to="/home"></Redirect>
            <Switch>
              <Route path='/home' component={Home}></Route>
  <Route path='/profile' component={Profile}></Route>
 
            </Switch>
          </Router>
        );
      };
      export default RouterView;
      
        