export const eventType = {
    onClick: 'onClick'
}