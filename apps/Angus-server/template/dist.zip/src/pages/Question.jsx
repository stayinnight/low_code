
        import AImage from '../components/widget/AImage.jsx' 
import AButton from '../components/widget/AButton.jsx' 


          import bfaefaaabcfaabaaacbbaaebaeaaaaadafba from '../assets/imgs/bf3ef180-cf23-57ac-b64e-6e68961dafb0.js' 


        const Question = () => {
          return (
            <div>
              <AImage

  url={bfaefaaabcfaabaaacbbaaebaeaaaaadafba}
style={{"width":200,"height":150,"borderWidth":1,"borderRadius":0,"borderStyle":"solid","borderColor":"#CECECE","left":258.5,"top":102.5}}


  />
<AButton

  propValue={'题库'}
style={{"width":80,"height":40,"fontSize":14,"fontWeight":500,"borderRadius":0,"textAlign":"center","color":"black","borderWidth":1,"borderColor":"","backgroundColor":"","borderStyle":"solid","left":299.5,"top":252.5}}


  />

            </div>
          );
        };

        export default Question;
       