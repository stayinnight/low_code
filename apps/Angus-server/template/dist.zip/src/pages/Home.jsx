
        import ARectAngle from '../components/widget/ARectAngle.jsx' 
import AImage from '../components/widget/AImage.jsx' 
import AButton from '../components/widget/AButton.jsx' 
import AText from '../components/widget/AText.jsx' 


          import aabadacabaaabbaaaabaaadbcaaaafabaaaa from '../assets/imgs/35b8d9c4-a47b-5032-a94d-ca942faba344.js' 


        const Home = () => { 
          return (
            <div>
              <ARectAngle

  style={{"width":365,"height":355,"borderRadius":0,"fontSize":14,"fontWeight":500,"borderWidth":1,"textAlign":"left","backgroundColor":"","borderStyle":"solid","borderColor":"#000F","color":"black","left":155.5,"top":87.5}}


  />
<AImage

  url={aabadacabaaabbaaaabaaadbcaaaafabaaaa}
style={{"width":300,"height":300,"borderWidth":10,"borderRadius":150,"borderStyle":"solid","borderColor":"#CECECE","left":186.5,"top":116.5}}


  />
<AButton

  propValue={'到信息页'}
style={{"width":186,"height":40,"fontSize":14,"fontWeight":500,"borderRadius":0,"textAlign":"center","color":"black","borderWidth":1,"borderColor":"","backgroundColor":"","borderStyle":"solid","left":155.5,"top":442.5}}


  />
<AButton

  propValue={'提交'}
style={{"width":174,"height":40,"fontSize":14,"fontWeight":500,"borderRadius":0,"textAlign":"center","color":"black","borderWidth":1,"borderColor":"","backgroundColor":"","borderStyle":"solid","left":346.5,"top":442.5}}


  />
<AText

  propValue={'我的主页'}
style={{"width":200,"height":43,"fontSize":14,"fontWeight":600,"lineHeight":3,"backgroundColor":"","textAlign":"center","color":"#1b4fe6","left":248.5,"top":44.5}}


  />
<ARectAngle

  propValue={'zc'}
style={{"width":250,"height":250,"borderRadius":125,"fontSize":140,"fontWeight":500,"borderWidth":5,"textAlign":"center","backgroundColor":"#e6124d","borderStyle":"solid","borderColor":"#2564e5","color":"#16da0d","left":208.5,"top":139.5}}


  />

            </div>
          );
        };

        export default Home;
       