
        import AImage from '../components/widget/AImage.jsx' 


          import aaaaaaaabeaaabaebebaaaabaedadcdcaffd from '../assets/imgs/aa72a323-e074-5ebe-8006-9ed3dcdc5ffd.js' 


        const Profile = () => { 
          return (
            <div>
              <AImage

  url={aaaaaaaabeaaabaebebaaaabaedadcdcaffd}
style={{"width":200,"height":150,"borderWidth":1,"borderRadius":0,"borderStyle":"solid","borderColor":"#CECECE","left":248.5,"top":131.5}}


  />

            </div>
          );
        };

        export default Profile;
       